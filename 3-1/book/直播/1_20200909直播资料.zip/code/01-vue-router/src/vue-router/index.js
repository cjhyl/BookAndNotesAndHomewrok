let _Vue = null
export default class VueRouter {
  constructor (options) {
    this.options = options
    // 记录路径和对应的组件
    this.routeMap = {}
    this.data = _Vue.observable({
      current: window.location.pathname
    })
  }

  init () {
    this.createRouteMap()
    this.initEvents()
    this.initComponents()
  }

  createRouteMap () {
    // routes => [{ name: '', path: '', component:  }]
    // 遍历所有的路由信息，记录路径和组件的映射
    this.options.routes.forEach(route => {
      // 记录路径和组件的映射关系
      this.routeMap[route.path] = route.component
    })
  }

  initEvents () {
    window.addEventListener('popstate', () => {
      this.data.current = window.location.pathname
    })
  }

  onHashChange () {
    this.app.current = window.location.hash.substr(1) || '/'
  }

  initComponents () {
    _Vue.component('RouterLink', {
      props: {
        to: String
      },
      render (h) {
        return h('a', {
          attrs: {
            href: this.to
          },
          on: {
            click: this.clickHanlder
          }
        }, [this.$slots.default])
      },
      methods: {
        clickHanlder (e) {
          history.pushState({}, '', this.to)
          this.$router.data.current = this.to
          e.preventDefault()
        }
      }
    })

    const self = this

    _Vue.component('RouterView', {
      render (h) {
        let component = self.routeMap[self.data.current]

        if (!component) {
          component = self.routeMap['*']
        }

        return h(component)
      }
    })
  }

  static install (Vue) {
    // 如果插件已经安装直接返回
    if (VueRouter.install.installed && _Vue === Vue) return

    VueRouter.install.installed = true
    _Vue = Vue

    Vue.mixin({
      beforeCreate () {
        // 判断 router 对象是否已经挂载了 Vue 实例上
        if (this.$options.router) {
          // 把 router 对象注入到 Vue 实例上
          _Vue.prototype.$router = this.$options.router
          // 初始化插件的时候，调用 init
          this.$options.router.init()
        }
      }
    })
  }
}
