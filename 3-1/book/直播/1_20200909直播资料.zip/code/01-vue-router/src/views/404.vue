<template>
  <div>
    这是一个漂亮的404
  </div>
</template>

<script>
export default {

}
</script>

<style>

</style>
