export default function createRouteMap (routes, pathList, pathMap) {
  pathList = pathList || []
  pathMap = pathMap || {} // {'/music': {...}, ...}

  routes.forEach(route => {
    addRouteRecord(route, pathList, pathMap)
  })

  return {
    pathList,
    pathMap
  }
}

function addRouteRecord (route, pathList, pathMap, parentRecord) {
  const path = parentRecord ? `${parentRecord.path}/${route.path}` : route.path

  const record = {
    path: path,
    component: route.component,
    parentRecord: parentRecord
  }

  if (!pathMap[path]) {
    pathList.push(path)
    pathMap[path] = record
  }

  // 处理子路由
  if (route.children) {
    route.children.forEach(childRoute => {
      addRouteRecord(childRoute, pathList, pathMap, record)
    })
  }
}
