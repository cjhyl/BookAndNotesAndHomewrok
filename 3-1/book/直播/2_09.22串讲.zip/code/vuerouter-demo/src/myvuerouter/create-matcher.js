import createRouteMap from './create-route-map'
import createRoute from './util/route'
export default function createMatcher (routes) {
  // 调用 createRouteMap() 生成路由表
  const { pathList, pathMap } = createRouteMap(routes)
  // console.log(pathList)
  // console.log(pathMap)
  // 根据路由地址返回路由规则
  function match (path) {
    const record = pathMap[path]
    if (record) {
      // 创建路由信息对象
      return createRoute(record, path)
    }
    return createRoute(null, path)
  }

  // console.log(match('/music/pop'))
  // 动态添加路由规则
  function addRoutes (routes) {
    createRouteMap(routes, pathList, pathMap)
  }

  return {
    match,
    addRoutes
  }
}
