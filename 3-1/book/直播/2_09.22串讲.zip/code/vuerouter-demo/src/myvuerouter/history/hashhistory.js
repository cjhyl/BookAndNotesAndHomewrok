import History from './history'

export default class HashHistory extends History {
  constructor (router) {
    super(router)
    // 确保首次访问的时候，路径中有 #
    ensureSlash()
  }

  getCurrentLocation () {
    return window.location.hash.substr(1)
  }

  setUpListener () {
    window.addEventListener('hashchange', () => {
      this.transitionTo(this.getCurrentLocation())
    })
  }
}

function ensureSlash () {
  if (window.location.hash) {
    return
  }
  window.location.hash = '/'
}
