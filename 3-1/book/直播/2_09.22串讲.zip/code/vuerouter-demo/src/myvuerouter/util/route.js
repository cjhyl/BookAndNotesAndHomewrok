export default function createRoute (record, path) {
  // 创建路由信息对象 { matched, path }
  const matched = []

  // /music/pop
  // /music
  while (record) {
    matched.unshift(record)
    record = record.parentRecord
  }

  return {
    matched,
    path
  }
}
