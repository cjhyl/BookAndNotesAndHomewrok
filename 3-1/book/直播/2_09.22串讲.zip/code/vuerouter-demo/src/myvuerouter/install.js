import link from './components/link'
import view from './components/view'

export let _Vue = null
export default function install (Vue) {
  _Vue = Vue
  Vue.mixin({
    beforeCreate () {
      if (this.$options.router) {
        // 此处是 new Vue()
        this._router = this.$options.router
        this._routerRoot = this
        this._router.init(this)
        // 定义一个响应式的属性，在transitionTo 中如果current 变化之后
        // 需要给 _route 重新赋值，响应式数据变化，视图要重新渲染
        Vue.util.defineReactive(this, '_route', this._router.history.current)
      } else {
        this._routerRoot = this.$parent && this.$parent._routerRoot
      }
    }
  })

  Object.defineProperty(Vue.prototype, '$router', {
    get () { return this._routerRoot._router }
  })

  Object.defineProperty(Vue.prototype, '$route', {
    get () { return this._routerRoot._route }
  })

  Vue.component(link.name, link)
  Vue.component(view.name, view)
}
