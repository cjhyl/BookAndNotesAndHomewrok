export default {
  name: 'RouterView',
  render (h) {
    // 路由信息对象 { matched, path }
    const route = this.$route
    let depth = 0

    // /music/pop
    this.routerView = true
    let parent = this.$parent

    while (parent) {
      console.log(this.$route.path)
      console.log(this)
      console.log(parent)
      if (parent.routerView) {
        depth++
      }
      parent = parent.$parent
    }

    const record = route.matched[depth]
    if (record) {
      // console.log(h(record.component))
      return h(record.component)
    }
    return h()
  }
}
