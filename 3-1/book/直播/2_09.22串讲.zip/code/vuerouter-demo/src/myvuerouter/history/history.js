import createRoute from '../util/route'
export default class History {
  constructor (router) {
    this.router = router
    // 记录当前的路由信息对象
    this.current = createRoute(null, '/')

    this.cb = null
  }

  listen (cb) {
    this.cb = cb
  }

  transitionTo (path, onComplete) {
    // 根据路由地址，匹配路由信息对象
    const current = this.router.matcher.match(path)

    this.router.beforeHooks.forEach(hooks => {
      hooks(current, this.current)
    })

    this.current = current
    // console.log(this.current)
    this.cb && this.cb(this.current)
    // 他内部注册路由地址变化的事件，在vuerouter初始化的时候
    onComplete && onComplete()
  }
}
