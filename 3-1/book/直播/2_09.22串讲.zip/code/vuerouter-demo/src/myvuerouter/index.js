import install from './install'
import createMatcher from './create-matcher'
import HashHistory from './history/hashhistory'
import HTML5History from './history/html5history'

export default class VueRouter {
  constructor (options) {
    this._routes = options.routes || []
    // { match, addRoutes }
    this.matcher = createMatcher(this._routes)

    this.beforeHooks = []

    const mode = this.mode = options.mode || 'hash'
    switch (mode) {
      case 'hash':
        this.history = new HashHistory(this)
        break
      case 'history':
        this.history = new HTML5History(this)
        break
      default:
        throw new Error('mode error')
    }
  }

  beforeEach (fn) {
    this.beforeHooks.push(fn)
  }

  init (app) {
    // app 就是 Vue 的实例
    const history = this.history

    const setUpListener = () => {
      history.setUpListener()
    }

    history.listen(current => {
      // 响应式数据发生变化，重新渲染视图
      app._route = current
      // console.log(app._route)
    })

    history.transitionTo(
      history.getCurrentLocation(),
      // 不能直接这么传递，他内部的this会有问题
      // history.setUpListener
      setUpListener
    )
  }
}

VueRouter.install = install
