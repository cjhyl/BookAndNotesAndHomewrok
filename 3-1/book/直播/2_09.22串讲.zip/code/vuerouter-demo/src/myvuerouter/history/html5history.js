import History from './history'

export default class HTML5History extends History {
  // constructor (router) {
  //   super(router)
  // }
}
