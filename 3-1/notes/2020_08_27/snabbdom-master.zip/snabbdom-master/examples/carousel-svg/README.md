This carousel example uses `style transform` and `transition` to rotate a group of SVG triangles.

Also, the color of each triangle changes when you hover or click/tap it.

\-- _jk_
