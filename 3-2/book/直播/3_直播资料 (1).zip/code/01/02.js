const man = {
  name:'jscoder',
  age:22
}

// ECMAScript 5 中使用它
Object.defineProperty(man, 'location', {
  get () {},
  set () {}
})
