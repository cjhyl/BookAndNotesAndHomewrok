const man = {
  name:'jscoder',
  age:22
}

// 1. Proxy 的使用
const p = new Proxy(man, {
  // 当你访问被代理对象的任何成员的时候会执行 get 方法
  get (target, property) {
    if (property in target) {
      return target[property]
    }

    // 2. JavaScript 抛出异常
    throw new Error(`Property "${property}" does not exist`)
  }
})

console.log(p.name)
console.log(p.abc)
