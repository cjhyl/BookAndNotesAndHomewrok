console.log(a)

let a = 123
