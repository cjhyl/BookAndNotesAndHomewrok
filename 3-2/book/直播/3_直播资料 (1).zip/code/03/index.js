var User = {
  count: 1,
  action: {
    getCount: function () {
      return this.count
    }
  }
}

var getCount = User.action.getCount

setTimeout(() => {
  console.log("result 1", User.action.getCount())
})

console.log("result 2", getCount()) // 函数调用没有主体，this 指向 Window 。a.fn() fn()

// result 2 undefined
// result 1 undefined
