function red () {
	console.log('red')
}

function green () {
	console.log('green')
}

function yellow () {
	console.log('yellow')
}

// 红灯三秒亮一次, 绿灯一秒亮一次, 黄灯2秒亮一次

// 封装一个 Promise 版本的定时器

// function main () {
//   timeout(red, 3000)
//     .then(() => {
//       return timeout(green, 1000)
//     })
//     .then(() => {
//       return timeout(yellow, 2000)
//     })
//     .then(() => {
//       console.log('一轮完成')
//       // 循环往复
//       main()
//     })
// }

async function main () {
  await timeout(red, 3000) // await 会等待后面的 Promise resolve 以后才会继续往下执行
  await timeout(green, 1000)
  await timeout(yellow, 2000)
  main()
}

main()

// 封装支持 Promise 的异步任务
function timeout (callback, time) {
  // 1. 返回一个 Promise
  return new Promise((resolve, reject) => {
    // 2. 在 Promise 函数中执行异步任务
    // 3. 成功 resolve，失败 reject
    setTimeout(() => {
      callback()
      // 成功 resolve
      resolve()
    }, time)
  })
}
