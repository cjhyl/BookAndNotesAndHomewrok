/** @type {import('@vue/cli-service').ProjectOptions} */
module.exports = {
  assetsDir: 'assets',
  chainWebpack: config => {
    // config.module.rules
  }
}