const rimraf = require('rimraf')

/** @type {import('@vue/cli-service').ServicePlugin} */
module.exports = (api, options = {}) => {
  // 类似 gulp 中的任务
  api.registerCommand('clean', (args, rawArgs) => {
    rimraf('./dist', err => {
      if (err) throw err
      console.log('clean completed.')
    })
  })

  // 可以使用 registerCommand 实现其他的自动化任务
  // deploy
  api.registerCommand('deploy', (args, rawArgs) => {
    // gh-pages
  })
}