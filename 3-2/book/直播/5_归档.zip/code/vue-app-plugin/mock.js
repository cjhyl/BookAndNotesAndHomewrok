// /** @type {import('@vue/cli-service').ServicePlugin} */
// module.exports = (api, options = {}) => {
//   api.configureDevServer(app => {
//     app.get('/api', (req, res) => {
//       res.json({ foo: 'bar' })
//     })
//   })
// }

const jsonServer = require('json-server')

/** @type {import('@vue/cli-service').ServicePlugin} */
module.exports = (api, options) => {
  api.configureDevServer(app => {
    app.use('/api', jsonServer.router('./db.json'))
  })
}