import { getPosts, getPosts2 } from './async-demo'

// 回调方式
// test('posts length is 100', (done) => {
//   getPosts(posts => {
//     expect(posts.length).toBe(100)
//     // 异步执行结束了
//     done()
//   })
// })

// test('async promise', () => {
//   // 务必返回 Promise
//   return getPosts2().then(posts => {
//     expect(posts.length).toBe(90)
//   })
// })

// test('async promise', () => {
//   // 务必返回 Promise
//   return expect(getPosts2()).resolves.toBe(100)
// })

// test('async test', async () => {
//   const count = await getPosts2()
//   expect(count).toBe(100)
// })

test('async test', () => {
  expect(100).toBe(100)
})
