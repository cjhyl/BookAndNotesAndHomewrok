export function sum (x, y) {
  return x + y
}

export function subtract (x, y) {
  return x - y
}

// exports.sum = sum
// exports.subtract = subtract
