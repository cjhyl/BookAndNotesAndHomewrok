import { Counter } from './counter'

let counter = null

// // 每个测试用例执行之前都来执行
beforeEach(() => {
  console.log('beforeEach')
  counter = new Counter()
})

// // 每个测试用例执行之后都来执行
// afterEach(() => {
//   console.log('beforeAfter')
// })

// // 所有测试用例执行之前执行
// beforeAll(() => {
//   console.log('beforeAll')
// })

// // 所有测试用例执行之后执行
// afterAll(() => {
//   console.log('afterAll')
// })

describe('Counter increment group1', () => {
  test('Counter increment', () => {
    console.log('Counter increment')
    // const counter = new Counter()
    // expect(counter.count).toBe(0)
    counter.increment()
    expect(counter.count).toBe(1)
    // counter
  })

  test('Counter decrement', () => {
    console.log('Counter decrement')
    // const counter = new Counter()
    // expect(counter.count).toBe(0)
    counter.decrement()
    expect(counter.count).toBe(-1)
    // counter
  })
})

describe('Counter increment group2', () => {
  // 当前组里面的每个测试用例执行之前都来调用
  beforeEach(() => {
    console.log('beforeEach group2')
  })
  test('Counter incrementTwo', () => {
    console.log('Counter incrementTwo')
    // const counter = new Counter()
    // expect(counter.count).toBe(0)
    counter.incrementTwo()
    expect(counter.count).toBe(2)
    // counter
  })

  test('Counter decrementTwo', () => {
    console.log('Counter decrementTwo')
    // const counter = new Counter()
    // expect(counter.count).toBe(0)
    counter.decrementTwo()
    expect(counter.count).toBe(-2)
    // counter
  })
})
