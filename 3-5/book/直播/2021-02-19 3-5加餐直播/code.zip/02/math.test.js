// npm run test
// jest
// babel-jest
// @babel/core ... 把 es6 模块转换为 commonjs 模块
// 把转换之后的模块给 jest 使用，运行测试代码

// const { sum, subtract } = require('./math')
import { sum, subtract } from './math'

test('测试 sum', () => {
  // 相等匹配器
  expect(sum(1, 2)).toBe(3)
})

test('测试 subtract', () => {
  expect(subtract(2, 1)).toBe(1)
})

test('测试对象', () => {
  const obj = { foo: 'bar' }
  // expect(obj).toBe({ foo: 'bar' })
  expect(obj).toEqual({ foo: 'bar' })
})

test('null', () => {
  const n = null
  expect(n).toBeNull()
  expect(n).toBeDefined()
  expect(n).not.toBeUndefined()
  expect(n).not.toBeTruthy()
  expect(n).toBeFalsy()
})

test('two plus two', () => {
  const value = 2 + 2
  expect(value).toBeGreaterThan(3) // 大于
  expect(value).toBeGreaterThanOrEqual(3.5) // 大于等于
  expect(value).toBeLessThan(5) // 小于
  expect(value).toBeLessThanOrEqual(4.5) // 小于等于

  // toBe and toEqual are equivalent for numbers
  expect(value).toBe(4)
  expect(value).toEqual(4)
})

test('两个浮点数字相加', () => {
  const value = 0.1 + 0.2
  // expect(value).toBe(0.3) // 这句会报错，因为浮点数有舍入误差
  expect(value).toBeCloseTo(0.3) // 这句可以运行
})

test('there is no I in team', () => {
  expect('team').not.toMatch(/I/)
})

test('but there is a "stop" in Christoph', () => {
  expect('Christoph').toMatch(/stop/)
})

const shoppingList = [
  'diapers',
  'kleenex',
  'trash bags',
  'paper towels',
  'milk'
]

test('the shopping list has milk on it', () => {
  expect(shoppingList).toContain('milk')
  expect(new Set(shoppingList)).toContain('milk')
})

function compileAndroidCode() {
  throw new Error('you are using the wrong JDK')
}

// 测试异常
test('compiling android goes as expected', () => {
  // expect(() => compileAndroidCode()).toThrow()
  // expect(() => compileAndroidCode()).toThrow(Error)

  // You can also use the exact error message or a regexp
  // expect(() => compileAndroidCode()).toThrow('you are using the wrong JDK')
  expect(() => compileAndroidCode()).toThrow(/JDK/)
})

const houseForSale = {
  bath: true,
  bedrooms: 4,
  kitchen: {
    amenities: ['oven', 'stove', 'washer'],
    area: 20,
    wallColor: 'white',
  },
};
const desiredHouse = {
  bath: true,
  kitchen: {
    amenities: ['oven', 'stove', 'washer'],
    wallColor: expect.stringMatching(/white|yellow/),
  },
};

test('the house has my desired features', () => {
  expect(houseForSale).toMatchObject(desiredHouse);
});
