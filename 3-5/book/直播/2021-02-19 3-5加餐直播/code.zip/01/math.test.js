const { sum, subtract } = require('./math')

// expect(sum(1, 2)).toBe(3)
// expect(subtract(2, 1)).toBe(1)

test('测试 sum', () => {
  expect(sum(1, 2)).toBe(3)
})

test('测试 subtract', () => {
  expect(subtract(2, 1)).toBe(1)
})

function test (description, callback) {
  try {
    callback()
  } catch (err) {
    console.log(`${description}：${err}`)
  }
}

function expect (result) {
  return {
    toBe (actual) {
      if (actual !== result) {
        throw new Error(`期望得到${actual}，但是得到了${result}`)
      }
    }
  }
}

// const result = sum(1, 2) // 实际值
// const expected = 3 // 期望的值

// if (result !== expected) {
//   throw new Error(`1 + 2 期望得到${expected}，但是得到了${result}`)
// }

// const result2 = subtract(2, 1) // 实际值
// const expected2 = 1 // 期望的值

// if (result2 !== expected2) {
//   throw new Error(`2 - 1 期望得到${expected2}，但是得到了${result}`)
// }
