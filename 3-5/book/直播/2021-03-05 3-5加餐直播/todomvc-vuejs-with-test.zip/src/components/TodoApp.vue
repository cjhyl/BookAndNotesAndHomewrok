<template>
  <section class="todoapp">
    <TodoHeader/>
    <!-- This section should be hidden by default and shown when there are todos -->
    <section class="main">
      <input id="toggle-all" class="toggle-all" type="checkbox" />
      <label for="toggle-all">Mark all as complete</label>
      <ul class="todo-list">
        <!-- These are here just to show the structure of the list items -->
        <!-- List items should get the class `editing` when editing and `completed` when marked as completed -->
        <TodoItem
          v-for="todo in todos"
          :key="todo.id"
          data-testid="todo-item"
        />
        <!-- <TodoItem/>
        <TodoItem/>
        <TodoItem/>
        <TodoItem/> -->
      </ul>
    </section>
    <!-- This footer should be hidden by default and shown when there are todos -->
    <TodoFooter/>
  </section>
</template>

<script>
import TodoHeader from './TodoHeader'
import TodoFooter from './TodoFooter'
import TodoItem from './TodoItem'

export default {
  components: {
    TodoHeader,
    TodoFooter,
    TodoItem
  },
  data () {
    return {
      todos: [
        { id: 1, text: 'eat', done: false },
        { id: 2, text: 'sleep', done: true },
        { id: 3, text: 'play', done: false }
      ] // 任务列表
    }
  }
}
</script>
