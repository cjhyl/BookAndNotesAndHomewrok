import TodoItem from '@/components/TodoItem'
import { mount, shallowMount } from '@vue/test-utils'
import Vue from 'vue'

describe('TodoApp.vue', () => {
  /**@type {import('@vue/test-utils').Wrapper} */
  let wrapper = null
  // 运行每个测试运行之前执行 beforeEach 这个钩子函数
  beforeEach(async () => {
    wrapper = shallowMount(TodoItem, {
      propsData: {
        todo: {
          id: 1,
          text: 'eat',
          done: false
        }
      }
    })
    // 确保视图更新之后再进行后续的内容测试
    await Vue.nextTick()
  })

  test('任务标题展示正常', () => {
    const label = wrapper.find('[data-testid="todo-text"]')
    expect(label.text()).toBe('eat')
  })

  test('任务完成状态正常', () => {
    const done = wrapper.find('[data-testid="todo-done"]')
    expect(done.element.checked).toBeFalsy()

    // 代码上线前，要把 data-testid 属性批量删掉吧
    // 结合 babel 可以实现 data-testid 批量删除
    // 但是不建议，为什么？如果你要做 e2e 端到端测试的话，e2e 测试的就是真实的 html 页面，它也要去获取元素
  })
})
