import TodoApp from '@/components/TodoApp'
import { mount, shallowMount } from '@vue/test-utils'
import Vue from 'vue'

describe('TodoApp.vue', () => {
  /**@type {import('@vue/test-utils').Wrapper} */
  let wrapper = null
  // 运行每个测试运行之前执行 beforeEach 这个钩子函数
  beforeEach(async () => {
    wrapper = shallowMount(TodoApp)
    wrapper.vm.todos = [
      { id: 1, text: 'eat', done: false },
      { id: 2, text: 'sleep', done: true },
      { id: 3, text: 'play', done: false }
    ]
    // 确保视图更新之后再进行后续的内容测试
    await Vue.nextTick()
  })

  it('任务列表展示正常', () => {
    // wrapper.vm
    const todoItems = wrapper.findAll('[data-testid="todo-item"]')
    expect(todoItems.length).toBe(3)
  })
})
