/** @type {import('@vue/cli-service').ProjectOptions} */
module.exports = {
  chainWebpack: config => {
    // config.module.rule()
  }
}