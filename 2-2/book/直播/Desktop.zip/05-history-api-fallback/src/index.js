// document.write('hello')

window.history.pushState('', '', '/home')