import Vue from 'vue' // C:\Users\zce\Desktop\16-vendors\node_modules\vue\dist\vue.js
import Vuex from 'vuex' // C:\Users\zce\Desktop\16-vendors\node_modules\vuex\dist\vuex.js
import VueRouter from 'vue-router'
import Axios from 'axios'
// import $ from 'jquery'

console.log(Vue)
console.log(Vuex)
console.log(VueRouter)
console.log(Axios)
// console.log($)