import './style.css'

console.log('mypack')