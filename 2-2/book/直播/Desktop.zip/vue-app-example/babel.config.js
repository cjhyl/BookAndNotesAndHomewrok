module.exports = {
  presets: [
    '@vue/babel-preset-app'
  ]
}
