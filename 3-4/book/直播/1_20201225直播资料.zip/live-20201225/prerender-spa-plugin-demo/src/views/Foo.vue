<template>
  <div>
    <h1>Foo Page</h1>
    <ul>
      <li class="post-list" v-for="post in posts" :key="post.id">{{ post.title }}</li>
    </ul>
  </div>
</template>

<script>
export default {
  name: 'FooPage',
  data () {
    return {
      posts: []
    }
  },
  created () {
    this.loadPosts()
  },
  methods: {
    async loadPosts () {
      const { data } = await this.$axios.get('https://jsonplaceholder.typicode.com/posts')
      this.posts = data
    }
  }
}
</script>

<style>

</style>
