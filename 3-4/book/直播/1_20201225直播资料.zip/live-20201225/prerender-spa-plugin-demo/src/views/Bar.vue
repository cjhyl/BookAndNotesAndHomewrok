<template>
  <div>
    <h1>Bar Page</h1>
  </div>
</template>

<script>
export default {
  name: 'BarPage'
}
</script>

<style>

</style>
