<template>
  <div id="app">
    <!-- 路由出口 -->
    <router-view/>
  </div>
</template>

<script>
export default {
  mounted () {
    // setTimeout(() => {
    //   // 发布一个自定义事件
    //   document.dispatchEvent(new Event('render-event'))
    // }, 5000)
  }
}
</script>

<style>
</style>
