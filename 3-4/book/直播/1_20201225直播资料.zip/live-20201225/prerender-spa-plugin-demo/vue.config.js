/**
 * Vue 中通过 vue.config.js 配置 webpack
 * 参考：https://cli.vuejs.org/zh/guide/webpack.html
 */
const path = require('path')
const PrerenderSPAPlugin = require('prerender-spa-plugin')
const Renderer = PrerenderSPAPlugin.PuppeteerRenderer

const isDev = process.env.NODE_ENV === 'development'

let config

if (isDev) {
  config = {}
} else {
  module.exports = {
    configureWebpack: { // 配置 webpack
      plugins: [
        // PrerenderSPAPlugin 的原理是使用了一个程序（无头浏览器）加载你渲染好的网页，使用爬虫的方式把页面内容抓取下来生成 html 文件
        // 它会在打包之后马上处理预渲染
        new PrerenderSPAPlugin({
          // 预渲染的文件目录，和打包结果目录一致
          staticDir: path.join(__dirname, 'dist'),
          // 配置哪些路由路径页面预渲染
          routes: [ '/', '/about', '/foo' ],
          renderer: new Renderer({
            renderAfterTime: 5000 // 等待页面加载 5s 后再处理预渲染
            
            // 等待页面中触发 Document 的 render-event 事件
            // 我是不是可以在请求 ajax 成功之后发布 render-event 事件
            // 但是 renderAfterDocumentEvent 有问题，目前只能在 Vue 根组件中使用
            // renderAfterDocumentEvent: 'render-event'

            // renderAfterElementExists: '.post-list',
          })
        })
      ]
    }
  }
}


