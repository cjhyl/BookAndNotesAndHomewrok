export default {
  // nuxt build 默认就是打包服务端渲染的代码
  // 如果仅需要客户单渲染，就像纯 Vue 一样，这里把 ssr: false
  ssr: false
}
