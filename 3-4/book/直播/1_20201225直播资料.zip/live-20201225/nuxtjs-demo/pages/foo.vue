<template>
  <div>
    <h1>Foo Page</h1>
  </div>
</template>

<script>
export default {

}
</script>

<style>

</style>
