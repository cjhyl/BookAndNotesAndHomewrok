import LgFormItem from '../form/src/formItem.vue'

LgFormItem.install = Vue => {
  Vue.component(LgFormItem.name, LgFormItem)
}

export default LgFormItem
