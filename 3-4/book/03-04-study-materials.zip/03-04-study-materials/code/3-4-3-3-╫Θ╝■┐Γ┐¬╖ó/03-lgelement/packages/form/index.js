import LgForm from './src/form.vue'

LgForm.install = Vue => {
  Vue.component(LgForm.name, LgForm)
}
console.log('test')
export default LgForm
