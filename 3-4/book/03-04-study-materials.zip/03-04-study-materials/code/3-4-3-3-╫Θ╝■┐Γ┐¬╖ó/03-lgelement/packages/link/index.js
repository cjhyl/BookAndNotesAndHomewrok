import LgLink from './src/link.vue'

LgLink.install = Vue => {
  Vue.component(LgLink.name, LgLink)
}

export default LgLink
