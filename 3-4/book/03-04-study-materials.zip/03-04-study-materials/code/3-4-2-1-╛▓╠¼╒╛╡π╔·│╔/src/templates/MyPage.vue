<template>
  <div>
    <h1>My Page</h1>
  </div>
</template>

<script>
export default {
  name: 'MyPage'
}
</script>

<style>

</style>
