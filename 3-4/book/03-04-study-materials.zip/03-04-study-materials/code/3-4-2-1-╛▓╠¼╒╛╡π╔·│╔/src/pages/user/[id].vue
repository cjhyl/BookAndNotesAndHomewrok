<template>
  <div>
    <h1>User {{ $route.params.id }} Page</h1>
  </div>
</template>

<script>
export default {
  name: 'UserPage'
}
</script>

<style>

</style>
