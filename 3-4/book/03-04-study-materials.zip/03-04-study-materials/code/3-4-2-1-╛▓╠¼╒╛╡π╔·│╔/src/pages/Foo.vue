<template>
  <div>
    <h1>Foo Page</h1>
  </div>
</template>

<script>
export default {
  name: 'FooPage',
  metaInfo: {
    title: 'Foo'
  }
}
</script>

<style>

</style>
